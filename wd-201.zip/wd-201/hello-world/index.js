const sanket = () =>{
    console.log("hello github")
    }
sanket()