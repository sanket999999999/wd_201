describe ("first test suite",() => {
  test ("first case" ,() =>{
    expect(true).toBe(true);
  })
})